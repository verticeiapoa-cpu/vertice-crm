# Vértice CRM 2.0 — reconstruído

Projeto recuperado a partir dos arquivos salvos do Replit.

## Rodar
```bash
uvicorn api.main:app --host 0.0.0.0 --port 5000
```
Abra `http://localhost:5000`.

## Banco
- Se `DATABASE_URL` existir, usa PostgreSQL.
- Caso contrário, cria `vertice_crm.db` com SQLite.

## IA
- Com `OPENAI_API_KEY`, tenta scoring via OpenAI.
- Sem chave ou em caso de falha, usa scoring heurístico local para manter o fluxo funcionando.

## Principais rotas
- `/api/health`
- `/api/clientes`
- `/api/leads`
- `/api/leads/import`
- `/api/leads/{id}/score`
- `/api/leads/score-batch`
- `/api/analytics`
- `/api/cnpj/{cnpj}`
