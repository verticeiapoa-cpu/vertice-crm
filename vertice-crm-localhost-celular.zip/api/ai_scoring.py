import os, json

def heuristic(lead):
    score=max(1,min(10, round((lead.ai_priority or 5)*.7 + (lead.score_vertice or 0)/100*3)))
    missing=[]
    if not lead.website: missing.append('presença digital/site')
    if not lead.telefone: missing.append('canal de contato')
    pain='Oportunidade de melhorar '+(' e '.join(missing) if missing else 'captação e conversão digital')+'.'
    pitch=f"Olá! Analisei a presença digital da {lead.empresa or lead.nome} e identifiquei uma oportunidade prática para melhorar a captação de clientes. Posso te mostrar em poucos minutos?"
    return {'ai_score':score,'pain_point':pain,'pitch_hook':pitch}

async def score_lead(lead):
    key=os.getenv('OPENAI_API_KEY')
    if not key: return heuristic(lead)
    try:
        from openai import AsyncOpenAI
        client=AsyncOpenAI(api_key=key)
        prompt=f'''Avalie este lead para uma agência digital brasileira. Retorne APENAS JSON com ai_score inteiro 0-10, pain_point em uma frase pt-BR e pitch_hook curto para WhatsApp. Empresa: {lead.empresa or lead.nome}; segmento: {lead.segmento}; site: {lead.website or 'não informado'}; telefone: {lead.telefone or 'não informado'}; score interno: {lead.score_vertice}.'''
        resp=await client.responses.create(model=os.getenv('OPENAI_MODEL','gpt-5-mini'),input=prompt)
        text=resp.output_text.strip().replace('```json','').replace('```','').strip(); data=json.loads(text)
        return {'ai_score':max(0,min(10,int(data['ai_score']))),'pain_point':str(data['pain_point']),'pitch_hook':str(data['pitch_hook'])}
    except Exception:
        return heuristic(lead)
