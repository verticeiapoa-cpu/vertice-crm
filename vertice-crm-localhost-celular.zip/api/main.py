import json, uuid, re
from datetime import datetime, timezone
from pathlib import Path
import httpx
from fastapi import FastAPI, Depends, HTTPException, Query
from fastapi.responses import FileResponse
from sqlalchemy.orm import Session
from sqlalchemy import or_
from .database import Base, engine, get_db
from .models import Lead, Cliente, Contato
from .schemas import LeadImport, BatchScore, StatusIn, ClienteIn, ClientePatch, ContatoIn
from .ai_scoring import score_lead
from .search import hunt_osm

ROOT=Path(__file__).resolve().parent.parent
Base.metadata.create_all(bind=engine)
app=FastAPI(title='Vértice CRM API',version='2.0-reconstructed')

def jloads(s, default=[]):
    try:return json.loads(s or '[]')
    except:return default

def lead_out(x):
    return {c.name:getattr(x,c.name) for c in x.__table__.columns}
def cliente_out(x):
    d={c.name:getattr(x,c.name) for c in x.__table__.columns if c.name!='historico_json'}; d['historico']=jloads(x.historico_json); return d

@app.get('/api/health')
def health(): return {'status':'ok','app':'vertice-crm','database':engine.url.get_backend_name()}
@app.get('/api/stats')
def stats(db:Session=Depends(get_db)):
    return {'total_leads':db.query(Lead).count(),'scored':db.query(Lead).filter(Lead.ai_score.isnot(None)).count()}
@app.post('/api/leads/hunt')
async def hunt(city:str,category:str='restaurant',radius:int=3000,hood:str|None=None): return {'elements':await hunt_osm(city,category,radius,hood)}
@app.post('/api/leads/import')
def import_leads(body:LeadImport, db:Session=Depends(get_db)):
    saved=[]; skipped=0
    for p in body.leads:
        q=[]
        if p.osm_id:q.append(Lead.osm_id==str(p.osm_id))
        if p.email:q.append(Lead.email==p.email)
        if p.cnpj:q.append(Lead.cnpj==p.cnpj)
        if q and db.query(Lead).filter(or_(*q)).first(): skipped+=1; continue
        lid=str(uuid.uuid4()); obj=Lead(id=lid,**p.model_dump()); obj.osm_id=str(obj.osm_id) if obj.osm_id else None; obj.nome=obj.nome or obj.empresa or 'Lead'; obj.empresa=obj.empresa or obj.nome
        db.add(obj); saved.append(lid)
    db.commit(); return {'saved':len(saved),'skipped':skipped,'saved_ids':saved,'message':f'{len(saved)} leads salvos; {skipped} duplicados ignorados.'}
@app.get('/api/leads')
def list_leads(status:str|None=None,segmento:str|None=None,min_priority:int=0,scored_only:bool=False,db:Session=Depends(get_db)):
    q=db.query(Lead)
    if status:q=q.filter(Lead.status==status)
    if segmento:q=q.filter(Lead.segmento==segmento)
    if min_priority:q=q.filter(Lead.ai_priority>=min_priority)
    if scored_only:q=q.filter(Lead.ai_score.isnot(None))
    return [lead_out(x) for x in q.order_by(Lead.criado_em.desc()).all()]
@app.get('/api/leads/{lead_id}')
def get_lead(lead_id:str,db:Session=Depends(get_db)):
    x=db.get(Lead,lead_id)
    if not x: raise HTTPException(404,'Lead não encontrado')
    return lead_out(x)
@app.put('/api/leads/{lead_id}/status')
def lead_status(lead_id:str,b:StatusIn,db:Session=Depends(get_db)):
    x=db.get(Lead,lead_id)
    if not x: raise HTTPException(404,'Lead não encontrado')
    x.status=b.status; db.commit(); db.refresh(x); return lead_out(x)
@app.delete('/api/leads/{lead_id}',status_code=204)
def del_lead(lead_id:str,db:Session=Depends(get_db)):
    x=db.get(Lead,lead_id)
    if x: db.delete(x); db.commit()
@app.post('/api/leads/{lead_id}/score')
async def score(lead_id:str,db:Session=Depends(get_db)):
    x=db.get(Lead,lead_id)
    if not x: raise HTTPException(404,'Lead não encontrado')
    d=await score_lead(x); x.ai_score=d['ai_score'];x.pain_point=d['pain_point'];x.pitch_hook=d['pitch_hook'];db.commit()
    return {'empresa':x.empresa or x.nome,**d}
@app.post('/api/leads/score-batch')
async def score_batch(b:BatchScore,db:Session=Depends(get_db)):
    xs=db.query(Lead).filter(Lead.ai_score.is_(None)).limit(b.limit).all(); out=[]
    for x in xs:
        d=await score_lead(x); x.ai_score=d['ai_score'];x.pain_point=d['pain_point'];x.pitch_hook=d['pitch_hook'];out.append({'empresa':x.empresa or x.nome,**d})
    db.commit(); return {'pontuados':len(out),'resultados':out}
@app.post('/api/leads/{lead_id}/contatos')
def add_contato(lead_id:str,b:ContatoIn,db:Session=Depends(get_db)):
    if not db.get(Lead,lead_id): raise HTTPException(404,'Lead não encontrado')
    o=Contato(lead_id=lead_id,canal=b.canal,resultado=b.resultado,observacao=b.observacao);db.add(o);db.commit();return {'ok':True,'id':o.id}

@app.get('/api/clientes')
def clients(db:Session=Depends(get_db)): return [cliente_out(x) for x in db.query(Cliente).order_by(Cliente.criado_em.desc()).all()]
@app.post('/api/clientes')
def add_client(b:ClienteIn,db:Session=Depends(get_db)):
    o=Cliente(id=str(uuid.uuid4()),**b.model_dump(exclude={'historico'}),historico_json=json.dumps(b.historico,ensure_ascii=False));db.add(o);db.commit();db.refresh(o);return cliente_out(o)
@app.post('/api/clientes/migrate')
def migrate(items:list[dict],db:Session=Depends(get_db)):
    n=0
    for d in items:
        try:
            b=ClienteIn.model_validate(d); add_client(b,db); n+=1
        except Exception: continue
    return {'migrados':n}
@app.get('/api/clientes/{cid}')
def get_client(cid:str,db:Session=Depends(get_db)):
    o=db.get(Cliente,cid)
    if not o: raise HTTPException(404,'Cliente não encontrado')
    return cliente_out(o)
@app.put('/api/clientes/{cid}')
def patch_client(cid:str,b:ClientePatch,db:Session=Depends(get_db)):
    o=db.get(Cliente,cid)
    if not o: raise HTTPException(404,'Cliente não encontrado')
    for k,v in b.model_dump(exclude_unset=True).items(): setattr(o,k,v)
    db.commit();db.refresh(o);return cliente_out(o)
@app.put('/api/clientes/{cid}/status')
def client_status(cid:str,b:StatusIn,db:Session=Depends(get_db)):
    o=db.get(Cliente,cid)
    if not o: raise HTTPException(404,'Cliente não encontrado')
    o.status=b.status;o.status_atualizado_em=datetime.now(timezone.utc);db.commit();db.refresh(o);return cliente_out(o)
@app.post('/api/clientes/{cid}/historico')
def history(cid:str,texto:str=Query(...),db:Session=Depends(get_db)):
    o=db.get(Cliente,cid)
    if not o: raise HTTPException(404,'Cliente não encontrado')
    h=jloads(o.historico_json);h.append({'texto':texto,'data':datetime.now().strftime('%d/%m/%Y')});o.historico_json=json.dumps(h,ensure_ascii=False);db.commit();return {'ok':True}
@app.delete('/api/clientes/{cid}',status_code=204)
def del_client(cid:str,db:Session=Depends(get_db)):
    o=db.get(Cliente,cid)
    if o:db.delete(o);db.commit()

@app.get('/api/cnpj/{cnpj}')
async def cnpj(cnpj:str):
    raw=re.sub(r'\D','',cnpj)
    if len(raw)!=14: raise HTTPException(400,'CNPJ inválido')
    try:
        async with httpx.AsyncClient(timeout=12) as c:r=await c.get(f'https://brasilapi.com.br/api/cnpj/v1/{raw}')
        if r.status_code!=200: raise HTTPException(404,'CNPJ não encontrado')
        d=r.json(); return {'razao_social':d.get('razao_social'),'nome_fantasia':d.get('nome_fantasia'),'atividade_principal':d.get('cnae_fiscal_descricao'),'municipio':d.get('municipio'),'uf':d.get('uf'),'data_abertura':d.get('data_inicio_atividade'),'situacao':d.get('descricao_situacao_cadastral'),'telefone':d.get('ddd_telefone_1')}
    except HTTPException:raise
    except Exception:raise HTTPException(502,'Serviço de CNPJ indisponível')

@app.get('/api/analytics')
def analytics(db:Session=Depends(get_db)):
    cs=db.query(Cliente).all(); ls=db.query(Lead).all(); pagos=[c for c in cs if c.pagamento=='pago']; pend=[c for c in cs if c.pagamento!='pago']
    receita=sum(c.valor or 0 for c in pagos); pendente=sum(c.valor or 0 for c in pend); pipe=sum(c.valor or 0 for c in cs if c.status in ('prospect','proposta'))
    dist={s:sum(1 for c in cs if c.status==s) for s in ('prospect','proposta','fechado','entregue','cancelado')}; seg={}
    for c in pagos:
        k=c.segmento or 'Outros';seg[k]=seg.get(k,0)+(c.valor or 0)
    fromleads=sum(1 for c in cs if c.lead_hunter_origin); converted=sum(1 for c in cs if c.lead_hunter_origin and c.status in ('fechado','entregue'))
    top=sorted([l for l in ls if l.ai_score is not None],key=lambda x:x.ai_score or 0,reverse=True)[:10]
    return {'taxa_conversao_pct':round((converted/fromleads*100) if fromleads else 0,1),'clientes_de_leads':fromleads,'receita_total':receita,'pipeline_valor':pipe,'ticket_medio':round(receita/len(pagos),2) if pagos else 0,'total_leads_db':len(ls),'leads_sem_scoring':sum(1 for l in ls if l.ai_score is None),'total_clientes':len(cs),'receita_pendente':pendente,'distribuicao_status':dist,'receita_por_segmento':seg,'top_leads':[{'empresa':l.empresa or l.nome,'segmento':l.segmento,'ai_score':l.ai_score,'pain_point':l.pain_point} for l in top]}

@app.get('/')
def index(): return FileResponse(ROOT/'index.html')
@app.get('/index.html')
def index2(): return FileResponse(ROOT/'index.html')
@app.get('/lead-hunter.html')
def lead_page(): return FileResponse(ROOT/'lead-hunter.html')
