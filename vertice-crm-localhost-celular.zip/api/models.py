from sqlalchemy import Column, String, Float, Integer, Boolean, DateTime, Text, ForeignKey
from sqlalchemy.sql import func
from .database import Base

class Lead(Base):
    __tablename__='leads'
    id=Column(String, primary_key=True)
    nome=Column(String, nullable=False)
    empresa=Column(String)
    telefone=Column(String); email=Column(String); linkedin=Column(String); cnpj=Column(String, unique=True)
    status=Column(String, default='Novo'); segmento=Column(String); endereco=Column(Text)
    lat=Column(Float); lng=Column(Float); score_vertice=Column(Integer, default=0); ai_priority=Column(Integer, default=0)
    website=Column(String); osm_id=Column(String, unique=True)
    ai_score=Column(Integer); pain_point=Column(Text); pitch_hook=Column(Text)
    criado_em=Column(DateTime(timezone=True), server_default=func.now()); atualizado_em=Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())

class Cliente(Base):
    __tablename__='clientes'
    id=Column(String, primary_key=True)
    nome=Column(String, nullable=False); negocio=Column(String, nullable=False); whatsapp=Column(String)
    segmento=Column(String); pacote=Column(String); valor=Column(Float); status=Column(String, default='prospect'); pagamento=Column(String, default='pendente')
    prazo=Column(String); obs=Column(Text); cnpj=Column(String); historico_json=Column(Text, default='[]')
    lead_hunter_origin=Column(Boolean, default=False); lead_db_id=Column(String)
    criado_em=Column(DateTime(timezone=True), server_default=func.now()); status_atualizado_em=Column(DateTime(timezone=True), server_default=func.now())

class Contato(Base):
    __tablename__='contatos'
    id=Column(Integer, primary_key=True, autoincrement=True); lead_id=Column(String, ForeignKey('leads.id'), nullable=False)
    canal=Column(String); resultado=Column(String); observacao=Column(Text); criado_em=Column(DateTime(timezone=True), server_default=func.now())
