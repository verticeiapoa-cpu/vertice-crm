from pydantic import BaseModel, Field
from typing import Optional, Any

class LeadIn(BaseModel):
    nome: Optional[str]=None; empresa: Optional[str]=None; telefone: Optional[str]=None; email: Optional[str]=None; linkedin: Optional[str]=None; cnpj: Optional[str]=None
    status: str='Novo'; segmento: Optional[str]=None; endereco: Optional[str]=None; lat: Optional[float]=None; lng: Optional[float]=None
    score_vertice: int=0; ai_priority: int=0; website: Optional[str]=None; osm_id: Optional[str]=None
class LeadImport(BaseModel): leads: list[LeadIn]
class BatchScore(BaseModel): limit: int=Field(10, ge=1, le=50)
class StatusIn(BaseModel): status: str
class ClienteIn(BaseModel):
    nome:str; negocio:str; whatsapp:Optional[str]=None; segmento:Optional[str]=None; pacote:Optional[str]=None; valor:Optional[float]=None
    status:str='prospect'; pagamento:str='pendente'; prazo:Optional[str]=None; obs:Optional[str]=None; cnpj:Optional[str]=None
    historico:list[dict[str,Any]]=[]; lead_hunter_origin:bool=False; lead_db_id:Optional[str]=None
class ClientePatch(BaseModel):
    nome:Optional[str]=None; negocio:Optional[str]=None; whatsapp:Optional[str]=None; segmento:Optional[str]=None; pacote:Optional[str]=None; valor:Optional[float]=None
    status:Optional[str]=None; pagamento:Optional[str]=None; prazo:Optional[str]=None; obs:Optional[str]=None; cnpj:Optional[str]=None
class ContatoIn(BaseModel): lead_id:str; canal:str; resultado:str; observacao:Optional[str]=None
