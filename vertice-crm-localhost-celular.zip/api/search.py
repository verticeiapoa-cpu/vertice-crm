import httpx
OSM_MAP={'restaurant':('amenity','restaurant'),'hairdresser':('shop','hairdresser'),'barber':('shop','barber'),'gym':('leisure','fitness_centre'),'dentist':('amenity','dentist'),'lawyer':('office','lawyer'),'real_estate_agent':('office','estate_agent'),'car_repair':('shop','car_repair'),'clothes':('shop','clothes'),'accountant':('office','accountant'),'physiotherapist':('healthcare','physiotherapist'),'veterinary':('amenity','veterinary'),'florist':('shop','florist'),'bakery':('shop','bakery'),'pharmacy':('amenity','pharmacy'),'supermarket':('shop','supermarket'),'hardware':('shop','hardware'),'beauty':('shop','beauty')}
async def hunt_osm(city:str, category:str='restaurant', radius:int=3000, hood:str|None=None):
    q=f'{hood}, {city}, Brasil' if hood else f'{city}, Brasil'
    headers={'User-Agent':'VerticeCRM/2.0 (lead research)'}
    async with httpx.AsyncClient(timeout=35, headers=headers) as c:
        g=await c.get('https://nominatim.openstreetmap.org/search',params={'q':q,'format':'json','limit':1,'countrycodes':'br'})
        g.raise_for_status(); gd=g.json()
        if not gd: return []
        lat,lon=float(gd[0]['lat']),float(gd[0]['lon']); k,v=OSM_MAP.get(category,('amenity',category))
        query=f'[out:json][timeout:25];(node["{k}"="{v}"](around:{radius},{lat},{lon});way["{k}"="{v}"](around:{radius},{lat},{lon}););out center tags meta;'
        r=await c.post('https://overpass-api.de/api/interpreter',data={'data':query}); r.raise_for_status(); return r.json().get('elements',[])
